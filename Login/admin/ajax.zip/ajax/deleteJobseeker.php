<?php
include "../../dbconn.php";
$result = $sr_no = "";
if(isset($_GET['sr_no']))
{
    try{
        $sr_no = $_GET['sr_no'];
        $stmt = $conn->prepare("delete from jobseeker where sr_no = ?");
        $stmt->bindParam(1, $sr_no);
        $stmt->execute();

        $result = "111";
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}

echo $result;
